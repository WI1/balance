$Id$

INSTALL
=======
These are temp installation instructions while SPARQL Views is in heavy
development.

1. Apply the patch in issue http://drupal.org/node/847492.


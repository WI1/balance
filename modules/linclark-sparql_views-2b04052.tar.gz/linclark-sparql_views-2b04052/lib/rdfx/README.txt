RDFx module is provided simply as a library for SPARQL Views in Drupal 6. It is
a full fledged module in Drupal 7.